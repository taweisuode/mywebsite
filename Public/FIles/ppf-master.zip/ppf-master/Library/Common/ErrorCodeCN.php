<?php
/**
 *  错误码对应中文的文件
 */
	$lang_cn[ErrorCode::test] 		= "测试测试";
?>
