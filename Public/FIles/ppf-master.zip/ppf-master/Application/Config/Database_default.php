<?php

/**
 * 请将该文件重命名为Database.php，并完善好配置，数据库才能work
 */
$database_config = array(
    'host' => '',
    'username'=>'',
    'password'=>'',
    'dbname'=>'',
    'charset'=>'',
    );
?>
